import zipfile
import os

'''
Develop a program to backing up a given Folder (Folder in a current working
directory) into a ZIP File by using relevant modules and suitable methods.
'''
def backup_folder(folder_path, zip_path):
    # Create a ZIP file object
    with zipfile.ZipFile(zip_path, 'w') as zip_file:
        # Iterate over all the files and subdirectories in the folder
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                # Get the full path of the file
                file_path = os.path.join(root, file)
                # Add the file to the ZIP file
                zip_file.write(file_path, os.path.relpath(file_path, folder_path))

# Specify the folder path and the ZIP file path
folder_path = '/home/himanshu/Desktop/python_lab'
zip_path = '/home/himanshu/Desktop/python_lab/backup.zip'

# Call the backup_folder function
backup_folder(folder_path, zip_path)